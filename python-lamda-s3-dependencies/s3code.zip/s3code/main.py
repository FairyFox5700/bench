import json
import pandas as pd
import boto3
import csv


def lambda_handler(event, context):
    # set up S3 client
    s3 = boto3.client('s3')
    # set up file name and bucket name
    bucket_name = 'benchmark-full-results'
    file_name = 'benchmark-full-results.csv'
    #Get our bucket and file name
    bucket = event['Records'][0]['s3']['bucket']['name']
    # Get a list of all CSV files in the bucket
    files = s3.list_objects_v2(Bucket=bucket, Prefix='', Delimiter='/')
    csv_files = [file['Key'] for file in files['Contents'] if file['Key'].endswith('.csv')]
    
    r_count = []
    op_count = []
    th_count = []
    clean_op_count = []

    db = []
    runtime = []
    throughput = []

    read_avg_latency = []
    cup_avg_latency = []
    update_avg_latency = []
    scan_avg_latency = []
    insert_avg_latency = []
    workload_type = []
    update_fail = []
    ram = []

    for filename in csv_files:
        path_to_file =  filename
        r_count.append(extract_value_from_filename(path_to_file,'records'))
        op_count.append(extract_value_from_filename(path_to_file,'operations'))
        workload_type.append(extract_value_from_filename(path_to_file,'workload'))
        th_count.append(extract_value_from_filename(path_to_file,'threads'))
        db.append(extract_value_from_filename(path_to_file,'database'))
        clean_op_count.append(find_param(path_to_file, '[CLEANUP], Operations, '))
        runtime.append(find_param(path_to_file, 'RunTime(ms), '))
        throughput.append(find_param(path_to_file, 'Throughput(ops/sec), '))
        read_avg_latency.append(find_param(path_to_file, '[READ], AverageLatency(us), '))
        update_avg_latency.append(find_param(path_to_file, '[UPDATE], AverageLatency(us), '))
        cup_avg_latency.append(find_param(path_to_file, '[CLEANUP], AverageLatency(us), '))
        scan_avg_latency.append(find_param(path_to_file, '[SCAN], AverageLatency(us), '))
        insert_avg_latency.append(find_param(path_to_file, '[INSERT], AverageLatency(us), '))
        update_fail.append(find_param(path_to_file, '[UPDATE-FAILED], Operations, '))


    Data = {'Record Count': r_count,
    'Database': db,
    'Runtime (ms)': runtime,
    'Throughput (ops/s)': throughput,
    'Average Read Latency (us)': read_avg_latency,
    'Average Clean Up Latency (us)': cup_avg_latency,
    'Clean Up Operations': clean_op_count,
    'Average Scan Latency (us)': scan_avg_latency,
    'Average Update Latency (us)': update_avg_latency,
    'Average Insert Latency (us)': insert_avg_latency,
    'Failed Updates': update_fail,
    'Query Count': op_count,
    'Thread Count': th_count,
    'Workload Type': workload_type
    }

    df = pd.DataFrame(Data, columns=['Record Count', 'Database', 'Runtime (ms)', 'Throughput (ops/s)', 'Average Read Latency (us)',
    'Average Clean Up Latency (us)', 'Clean Up Operations', 'Average Scan Latency (us)',
    'Average Update Latency (us)', 'Average Insert Latency (us)', 'Failed Updates', 'Query Count', 'Thread Count',
    'Workload Type'])


    df[['Record Count', 'Runtime (ms)', 'Throughput (ops/s)', 'Average Read Latency (us)', 'Average Clean Up Latency (us)',
    'Clean Up Operations', 'Average Scan Latency (us)', 'Average Update Latency (us)','Average Insert Latency (us)',  'Failed Updates', 'Query Count',
    'Thread Count']] = df[['Record Count', 'Runtime (ms)', 'Throughput (ops/s)', 'Average Read Latency (us)',
    'Average Clean Up Latency (us)', 'Clean Up Operations', 'Average Scan Latency (us)',
    'Average Update Latency (us)','Average Insert Latency (us)', 'Failed Updates', 'Query Count', 'Thread Count']].apply(pd.to_numeric)

    data = df.to_csv('benchmark.csv', index=False)
    
    responce_from_upload = s3.put_object(Bucket=bucket_name, Key=file_name, Body=data)

    return {
        'statusCode': 200,
        'body': json.dumps('responce_from_upload')
    }

def find_param(file_name, string_to_search):
    standard = 'utf-8'
    with open(file_name, 'r', encoding = standard) as read_obj:
        for line in read_obj:
            if string_to_search in line:
                param=line.split(string_to_search)[1]
                param=param.split()[0]
                return param
                break
    if string_to_search == '[UPDATE-FAILED], Operations, ':
        return

def extract_value_from_filename(path, variable):
    filename = path.split(".")[0]
    # Split the string into a list of substrings
    parts =  filename.split('_')
    # Initialize the value variable
    value = None

    # Loop through the list of substrings
    for part in parts:
        # Extract the value of the variable based on the substring
        if part.startswith(variable + "="):
            value = part.split("=")[1]
            break

    # If the value is numeric, convert it to an integer
    if value is not None and value.isnumeric():
        value = int(value)

    return value